package com.example.work_with_subd;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Show extends AppCompatActivity {

    Button remove;
    TextView list;
    Button add;
    public static MainActivity.DataSQL dataBase;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        dataBase = new MainActivity.DataSQL(this);
        remove = findViewById(R.id.btnDelete);
        list = findViewById(R.id.list);
        add = findViewById(R.id.add);
        Cursor c = dataBase.query("mytable");
        if (c.moveToFirst()) {
            int nameIndex = c.getColumnIndex("name");
            int dateIndex = c.getColumnIndex("date");
            do {
                list.setText(list.getText()+ "\n" + c.getString(nameIndex) + " до " + c.getString(dateIndex));
            } while (c.moveToNext());
        }
        c.close();
        remove.setOnClickListener(v -> {
            dataBase.remove("mytable");
            Toast.makeText(getApplicationContext(), "Отчищено!", Toast.LENGTH_SHORT).show();
            list.setText("");
        });
        add.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
    }
}
