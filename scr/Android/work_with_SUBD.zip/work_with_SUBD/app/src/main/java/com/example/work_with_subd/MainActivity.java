package com.example.work_with_subd;

import static com.example.work_with_subd.Show.dataBase;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button date;
    Button add;
    Button get;
    EditText name;
    String deadline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add = findViewById(R.id.btAdd);
        get = findViewById(R.id.btnRead);
        date = findViewById(R.id.pick_date);
        name = findViewById(R.id.etName);

        this.date.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int mMonth = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            @SuppressLint("SetTextI18n")
            DatePickerDialog dpd = new DatePickerDialog(MainActivity.this,
                    (view, year_p, monthOfYear_p, dayOfMonth_p) -> deadline = dayOfMonth_p + "-" + (monthOfYear_p + 1) + "-" + year_p, year, mMonth, day);
            dpd.show();
        });
        add.setOnClickListener(v -> {
            dataBase.insert("mytable", new String[]{"name", "date"}, new String[]{this.name.getText().toString(), deadline});
            Toast.makeText(getApplicationContext(), "Добавлено!", Toast.LENGTH_SHORT).show();
            name.setText("");
        });
        get.setOnClickListener(v -> startActivity(new Intent(this, Show.class)));
    }


    public static class DataSQL extends SQLiteOpenHelper{

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table mytable ("
                    + "id integer primary key autoincrement,"
                    + "name text,"
                    + "date text);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

        public DataSQL(Context context) {
            super(context, "MyDB", null, 1);
        }

        public void remove(String table){
            remove(table, null, null);
        }

        public void remove(String table, String clause, String[] args){
            getWritableDatabase().delete(table, clause, args);
            close();
        }

        public void insert(String table, String clause, ContentValues args){
            getWritableDatabase().insert(table, clause, args);
            close();
        }

        public void insert(String table, String[] name, String[] value){
            ContentValues cv = new ContentValues();
            for (int i = 0; i < name.length; i++) {
                cv.put(name[i], value[i]);
            }
            insert(table, null, cv);
        }

        public void insert(String table, String name, String value){
            ContentValues cv = new ContentValues();
            cv.put(name, value);
            insert(table, null, cv);
        }

        public Cursor query(String table, String[] columns, String selection, String[] selectionArg, String groupBy, String having, String orderBy){
            return getWritableDatabase().query(table, columns, selection, selectionArg, groupBy, having, orderBy);
        }

        public Cursor query(String table){
            return query(table, null, null, null, null, null, null);
        }

    }
}