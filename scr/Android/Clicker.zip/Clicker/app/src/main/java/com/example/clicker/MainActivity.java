package com.example.clicker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mainText;
    ImageButton mainBtn;
    Button resetBtn, decreaseBtn;
    private long score = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainText = (TextView) findViewById(R.id.mainTxt);
        mainBtn = (ImageButton) findViewById(R.id.main_btn);
        resetBtn = (Button) findViewById(R.id.reset_btn);
        decreaseBtn = (Button) findViewById(R.id.decrease_btn);

        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Helper(1);
            }
        };
        mainBtn.setOnClickListener(clickListener);
        View.OnClickListener clickListener1 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Helper(3);
            }
        };
        resetBtn.setOnClickListener(clickListener1);

        View.OnClickListener clickListener2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Helper(2);
            }
        };
        decreaseBtn.setOnClickListener(clickListener2);

    }

    private void Helper(int btn){
        if (btn == 1) {
            score++;
        }
        else if (btn == 2) {
            score--;
        }
        else {
            score = 0;
        }
        String s;
        if (score >= 0) {
            if (score % 10 > 1 && score % 10 < 5) {
                s = "Кнопка нажата " + score + " раза";
            } else {
                s = "Кнопка нажата " + score + " раз";
            }
        }
        else {
            s ="Кнопка нажата 0 раз";
            score = 0;
        }
        mainText.setText(s.toCharArray(), 0, s.length());
    }
}



