package com.example.seckondwindow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (String.valueOf(item.getTitle()).equals("Перейти на второе окно")){
            Intent intent = new Intent(this, MainActivity2.class);
            startActivity(intent);
        }
        else if (String.valueOf(item.getTitle()).equals("Перейти на первое окно")){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if (String.valueOf(item.getTitle()).equals("Перейти на четвертое окно")){
            Intent intent = new Intent(this, MainActivity4.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}