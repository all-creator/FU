package com.example.guess_number;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ZygotePreload;
import android.view.Menu;
import android.view.View;
import android.widget.*;
import android.os.Bundle;

import java.io.IOError;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Button button;
    EditText editText;

    int guess = new Random().nextInt(100);

    @SuppressLint("SetTextI18n")
    View.OnClickListener view = (view1 -> {
        int number = 0;
        boolean status;
        try {
            number = Integer.parseInt(editText.getText().toString());
            status = true;

        }
        catch (NumberFormatException e){
            status = false;
        }
        if(status){
            if (number == guess){
                textView.setText(getResources().getString(R.string.hit));
            }
            if (number > guess){
                textView.setText(getResources().getString(R.string.ahead));
            }
            if (number < guess){
                textView.setText(getResources().getString(R.string.behind));
            }
            if (number < 0 || number > 100){
                textView.setText("Вводите числа от 0 до 100");
            }
        }else
        {
            button.setText(getResources().getString(R.string.input_value));
            textView.setText(getResources().getString(R.string.error));
            textView.setText(getResources().getString(R.string.try_to_guess));
            guess = new Random().nextInt(100);
        }
        editText.clearComposingText();
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.message);
        editText = (EditText) findViewById(R.id.input);
        button = (Button) findViewById(R.id.main_btn);
        button.setOnClickListener(view);
    }
}