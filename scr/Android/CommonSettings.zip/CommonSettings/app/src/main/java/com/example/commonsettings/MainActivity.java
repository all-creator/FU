package com.example.commonsettings;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button save;
    Button load;
    Button date;
    EditText name;
    TextView show_date;
    TextView age;
    TextView info;
    RadioGroup radioGroup;
    int year, month, day;
    SeekBar seekBar;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        save = findViewById(R.id.btn_save);
        load = findViewById(R.id.btn_load);
        name = findViewById(R.id.stud_name);
        info = findViewById(R.id.info);
        show_date = findViewById(R.id.show_date);
        date = findViewById(R.id.pick_date);
        seekBar = findViewById(R.id.pick_age);
        radioGroup = findViewById(R.id.radioGroup);
        age = findViewById(R.id.age);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                age.setText(String.valueOf(seekBar.getProgress()));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                age.setText("16");
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        this.date.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            year = c.get(Calendar.YEAR);
            month = c.get(Calendar.MONTH);
            day = c.get(Calendar.DAY_OF_MONTH);
            @SuppressLint("SetTextI18n") DatePickerDialog dpd = new DatePickerDialog(MainActivity.this,
                    (view, year, monthOfYear, dayOfMonth) -> show_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year), year, month, day);
            dpd.show();

        });
        save.setOnClickListener(v -> save());
        load.setOnClickListener(v -> load());
    }

    @SuppressLint("SetTextI18n")
    private void save(){
        SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
        String name = !this.name.getText().toString().equals("") ? this.name.getText().toString() : "Не определено";
        String age = !this.age.getText().toString().equals("") ? this.age.getText().toString() : "Не определено";
        String birthdate = !show_date.getText().toString().equals("") ? show_date.getText().toString() : "Не определено";
        ed.putString("name: ", name);
        ed.putString("age: ", age);
        ed.putString("Birth date: ", birthdate);
        RadioButton group_rb = findViewById(radioGroup.getCheckedRadioButtonId());
        String group = group_rb != null ? group_rb.getText().toString() : "Не определено";
        ed.putString("Group: ", group);
        ed.apply();
        info.setText("Сохранено: " + name + " " + age + " лет " + birthdate + " дата роджения: " + group + " группа");
    }

    @SuppressLint("SetTextI18n")
    private void load(){
        SharedPreferences pref = getPreferences(MODE_PRIVATE);
        String name = pref.getString("name: ", "Не определено" );
        String age = pref.getString("age: ", "Не определено");
        String birthdate = pref.getString("Birth date: ", "Не определено");
        String group = pref.getString("Group: ", "Не определено");
        info.setText("Загружено: " + name + ", " + age + " лет, " + birthdate + " дата роджения, " + group + " группа");
        this.name.setText("");
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        save();
    }
}