package com.example.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    CheckBox chb;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.textView);
        chb = (CheckBox) findViewById(R.id.chbExtMenu);
    }

    // Создание меню
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Обновление меню
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.setGroupVisible(R.id.g1, chb.isChecked());
        return super.onPrepareOptionsMenu(menu);
    }

    // Обработка нажатий
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        StringBuilder sb = new StringBuilder();
        if (String.valueOf(item.getTitle()).equals("exit")){
            finish();
        }
        sb.append("Item Menu").append("\r\n groupId: ").append(item.getGroupId())
                .append("\r\n itemId: ").append(item.getItemId()).append("\r\n order: ")
                .append(item.getOrder()).append("\r\n title: ").append(item.getTitle());
        tv.setText(sb.toString());

        return super.onOptionsItemSelected(item);
    }
}

